# Olympic-Analysis
 This project analyzes Olympic Games data using Python on dataset from Kaggle. The analysis is presented through a custom-built webpage that offers various insights into the Olympics. The webpage is developed using Python, with the coding done in Google Colab and PyCharm.
